import { Component } from '@angular/core'

@Component({
  selector: 'app-devs',
  standalone: true,
  imports: [],
  templateUrl: './devs.component.html',
  styleUrl: './devs.component.css'
})
export class DevsComponent {

}
