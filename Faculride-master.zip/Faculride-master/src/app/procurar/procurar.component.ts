import { Component } from '@angular/core';
import { Router } from '@angular/router';



import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-procurar',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './procurar.component.html',
  styleUrl: './procurar.component.css'
})
export class ProcurarComponent {

}







